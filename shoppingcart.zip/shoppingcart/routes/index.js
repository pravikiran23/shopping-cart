var express = require('express');
var router = express.Router();
var product=require('../models/product');




/* GET home page. */
router.get('/', function(req, res, next) {
  product.find(function(err,docs){
    var productchunks=[];
    var chunksize=3;
    for(var i=0;i<docs.length;i+=chunksize){
      productchunks.push(docs.slice(i,i+chunksize));

    }
    res.render('shop/index', { title: 'Shoppingcart',products: productchunks });
  });
  
});
router.get('/add-to-cart/:id',function(req,res,next){
  var productId=req.params.id;
});


module.exports = router;
 