var product=require('../models/product');
var mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/shopping', { useNewUrlParser: true });
 
var products= [
    new product({
            imagepath:'https://www.mbofpleasanton.com/assets/stock/expanded/white/640/2019mbcbj_640/2019mbcbj0001_640_07.jpg',
             title:'benz',
            description:'cla class',
            price:3000000
    }),

    new product({
        imagepath:'http://685f8555a5ea0066dc08-b2a9526d4cdcc7c5e6a5c112f9ea9e9b.r47.cf1.rackcdn.com/thumbnails/55SWF4KB7HU187750/5a9e3f38b5103c02c469f4ab2dc619a7.jpg',
         title:'benz',
        description:'c class',
        price:4000000
}),
new product({
    imagepath:'https://images.dealer.com/ddc/vehicles/2019/Mercedes-Benz/E-Class/Sedan/trim_Base_6e217d/color/Polar%20White-149-227%2C228%2C232-640-en_US.jpg?impolicy=resize&w=650',
     title:'benz',
    description:'e class',
    price:5000000
}),
new product({
    imagepath:'https://st.motortrend.com/uploads/sites/10/2017/10/2018-mercedes-benz-s-class-450-sedan-angular-front.png',
     title:'benz',
    description:'s class',
    price:10000000
}),
new product({
    imagepath:'https://auto.ndtvimg.com/car-images/big/mercedes-benz/gle-class/mercedes-benz-gle-class.jpg?v=8',
     title:'benz',
    description:'gle class',
    price:10000000
}),
new product({
    imagepath:'https://imgd.aeplcdn.com/310x174/cw/ec/20628/MercedesBenz-GLS-Exterior-137818.jpg?wm=0&q=85',
     title:'benz',
    description:'gls class',
    price:15000000
})
];

console.log("in product-seeder");
var done=0;
for(var i=0;i<products.length;i++){
    products[i].save(function(err,result){
done++;
console.log("in product-seeder loop");
if(done== products.length){
    ExtensionScriptApis();
}
    });
}
function exit()
{
    mongoose.disconnect();
}
